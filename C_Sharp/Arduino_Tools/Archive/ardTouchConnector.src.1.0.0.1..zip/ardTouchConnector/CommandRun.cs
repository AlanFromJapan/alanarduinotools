using System;
using System.Collections.Generic;
using System.Text;

namespace ardTouchConnector {
    public class CommandRun {
        public string mLabel = null;
        public string mKey = null;
        public string mCommand = null;
        public string mParams = null;
        public bool mMustConfirm = false;
    }
}
