using System;
using System.Collections.Generic;
using System.Text;
using ARCPO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace ardTouchConnector
{
    public class CommandRunPacketInterpreter : BasePacketInterpreter
    {
        #region Inner classes

        #endregion

        #region Attributes

        #endregion

        #region Properties

        /// <summary>
        /// Gets the xml selector to this interpreter specific custom commands
        /// </summary>
        protected override string MyCommandRunXMLPath {
            get {
                return "/commands/commandRunInterpreter/customRuns/customRun";
            }
        }
        #endregion

        

        #region IPacketInterpreter Members

        public override List<byte> AcceptedPacket()
        {
            List<byte> vL = new List<byte>(new byte[] { 
                (byte)'N',
                (byte)'X',
                (byte)'C',
                (byte)'Z',
                (byte)'G',
            });

            foreach (CommandRun vCR in this.CommandRunDict.Values) {
                vL.Add((byte)vCR.mKey[0]);
            }

            return vL;
        }



        public override void Interprete(ARCPO_Packet pPacket)
        {
            if (pPacket == null || pPacket.ContentString == null || pPacket.ContentString.Length == 0) {
                return;
            }

            switch (pPacket.ContentString[0]) { 
                case 'N':
                    RunNotepad();
                    break;
                case 'X':
                    RunCalculatrice();
                    break;
                case 'C':
                    RunCmd();
                    break;
                case 'Z':
                    RunCharmap();
                    break;
                default:
                    //is it a known custom command?
                    if (this.CommandRunDict.ContainsKey(pPacket.ContentString[0].ToString())) {
                        RunCustom(this.CommandRunDict[pPacket.ContentString[0].ToString()]);
                    }
                    break;
            }
        }

        /// <summary>
        /// Runs a custom command
        /// </summary>
        /// <param name="commandRun"></param>
        private void RunCustom(CommandRun pCommandRun)
        {
            if (pCommandRun.mMustConfirm &&
                DialogResult.Yes != MessageBox.Show("Are you sure you want to run "+pCommandRun.mLabel+" now ?", "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1))
            {
                return;
            }

            Process vP = new Process();
            vP.StartInfo.FileName = pCommandRun.mCommand;

            if (pCommandRun.mParams != null) {
                vP.StartInfo.Arguments = pCommandRun.mParams;
            }

            vP.Start();
        }


        private void RunNotepad()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "notepad.exe";

            vP.Start();
        }

        private void RunCalculatrice()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "calc.exe";

            vP.Start();
        }

        private void RunCharmap()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "charmap.exe";

            vP.Start();
        }

        private void RunCmd()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "cmd.exe";

            vP.Start();
        }



        #endregion
    }
}
