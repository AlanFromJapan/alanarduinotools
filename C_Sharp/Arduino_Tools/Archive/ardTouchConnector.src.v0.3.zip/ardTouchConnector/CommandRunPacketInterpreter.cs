using System;
using System.Collections.Generic;
using System.Text;
using ARCPO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Xml;
using System.IO;

namespace ardTouchConnector
{
    public class CommandRunPacketInterpreter : IPacketInterpreter
    {
        #region Inner classes
        public class CommandRun {
            public string mLabel = null;
            public string mKey = null;
            public string mCommand = null;
            public string mParams = null;
            public bool mMustConfirm = false;
        }
        #endregion

        #region Attributes

        private Dictionary<string, CommandRun> mCommandRunDict = null;

        #endregion

        #region Properties
        /// <summary>
        /// Gets the list of commandrun
        /// </summary>
        protected Dictionary<string, CommandRun> CommandRunDict {
            get {
                if (this.mCommandRunDict == null) { 
                    //initialize
                    this.mCommandRunDict = new Dictionary<string, CommandRun>();

                    XmlDocument vDoc = new XmlDocument();
                    vDoc.Load(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), XML_CUSTOM_COMMANDS));

                    foreach (XmlNode vN in vDoc.SelectNodes("/commands/commandRunInterpreter/customRuns/customRun"))
                    {
                        CommandRun vCR = new CommandRun();

                        vCR.mLabel = vN.Attributes["label"].Value;
                        vCR.mKey = vN.Attributes["key"].Value;
                        vCR.mCommand = vN.Attributes["command"].Value;
                        if (vN.Attributes["params"].Value != string.Empty) {
                            vCR.mParams = vN.Attributes["params"].Value;
                        }
                        vCR.mMustConfirm = Convert.ToBoolean(vN.Attributes["mustConfirm"].Value);

                        this.mCommandRunDict.Add(vCR.mKey, vCR);
                    }
                }

                return this.mCommandRunDict;
            }
        }
        #endregion

        public const string XML_CUSTOM_COMMANDS = "CustomCommands.xml";

        #region IPacketInterpreter Members

        public List<byte> AcceptedPacket()
        {
            List<byte> vL = new List<byte>(new byte[] { 
                (byte)'N',
                (byte)'X',
                (byte)'C',
                (byte)'Z',
                (byte)'G',
            });

            foreach (CommandRun vCR in this.CommandRunDict.Values) {
                vL.Add((byte)vCR.mKey[0]);
            }

            return vL;
        }



        public void Interprete(ARCPO_Packet pPacket)
        {
            if (pPacket == null || pPacket.ContentString == null || pPacket.ContentString.Length == 0) {
                return;
            }

            switch (pPacket.ContentString[0]) { 
                case 'N':
                    RunNotepad();
                    break;
                case 'X':
                    RunCalculatrice();
                    break;
                case 'C':
                    RunCmd();
                    break;
                case 'Z':
                    RunCharmap();
                    break;
                default:
                    //is it a known custom command?
                    if (this.CommandRunDict.ContainsKey(pPacket.ContentString[0].ToString())) {
                        RunCustom(this.CommandRunDict[pPacket.ContentString[0].ToString()]);
                    }
                    break;
            }
        }

        /// <summary>
        /// Runs a custom command
        /// </summary>
        /// <param name="commandRun"></param>
        private void RunCustom(CommandRun pCommandRun)
        {
            if (pCommandRun.mMustConfirm &&
                DialogResult.Yes != MessageBox.Show("Are you sure you want to run "+pCommandRun.mLabel+" now ?", "Please confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1))
            {
                return;
            }

            Process vP = new Process();
            vP.StartInfo.FileName = pCommandRun.mCommand;

            if (pCommandRun.mParams != null) {
                vP.StartInfo.Arguments = pCommandRun.mParams;
            }

            vP.Start();
        }


        private void RunNotepad()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "notepad.exe";

            vP.Start();
        }

        private void RunCalculatrice()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "calc.exe";

            vP.Start();
        }

        private void RunCharmap()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "charmap.exe";

            vP.Start();
        }

        private void RunCmd()
        {
            Process vP = new Process();
            vP.StartInfo.FileName = "cmd.exe";

            vP.Start();
        }



        #endregion
    }
}
