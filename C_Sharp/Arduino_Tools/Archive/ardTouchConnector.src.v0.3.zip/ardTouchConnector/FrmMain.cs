using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Threading;

namespace ardTouchConnector
{
    public partial class FrmMain : Form
    {
        /// <summary>
        /// The connector
        /// </summary>
        protected ATConnector mConnector = new ATConnector();

        /// <summary>
        /// Connects to Outlook, get mails count...
        /// </summary>
        protected OutlookConnector mOutlook = new OutlookConnector();

        /// <summary>
        /// The log form
        /// </summary>
        protected FrmLog mLogForm = null;


        protected Dictionary<byte, IPacketInterpreter> mRegisteredIntepreters = new Dictionary<byte, IPacketInterpreter>();


        #region Properties 
        /// <summary>
        /// Gets if the show log form should be shown
        /// </summary>
        public bool ShowLog {
            get { return this.mLogForm != null && !this.mLogForm.IsDisposed && this.mLogForm.Visible && ckbShowLog.Checked; }
        }
        #endregion

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            InitIntepreters();

            for (int i = 0; i <= 20; i++) {
                ddlCOMPort.Items.Add("COM" + i);
            }

            ddlCOMPort.SelectedIndex = ddlCOMPort.Items.IndexOf(ConfigurationManager.AppSettings["COMPort"]);

            mConnector.PacketReceived += new EventHandler<ARCPO.ARCPO_ReceivedEventArgs>(Connector_PacketReceived);
        }

        /// <summary>
        /// Registers all the known interpreters
        /// </summary>
        private void InitIntepreters()
        {
            CommandRunPacketInterpreter vI = new CommandRunPacketInterpreter();

            foreach (byte vB in vI.AcceptedPacket()) {
                this.mRegisteredIntepreters[vB] = vI;
            }
        }

        /// <summary>
        /// Handles the reception of the mesage. BEWARE IT'S NOT ON THE UI Thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Connector_PacketReceived(object sender, ARCPO.ARCPO_ReceivedEventArgs e)
        {
            this.Invoke(new EventHandler<ARCPO.ARCPO_ReceivedEventArgs>(this.Connector_PacketReceived_CROSSTHREADED), sender, e);
        }

        /// <summary>
        /// Manages the reception of message ON THE UI THREAD
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Connector_PacketReceived_CROSSTHREADED(object sender, ARCPO.ARCPO_ReceivedEventArgs e)
        {
            //Log ?
            if (ShowLog) {
                this.mLogForm.LogMessage(e.ReceivedTime, true, e.Packet);
            }

            //do something ?
            if (e.Packet != null && e.Packet.ContentString != null && e.Packet.ContentString.Length > 0) {
                if (this.mRegisteredIntepreters.ContainsKey((byte)e.Packet.ContentString[0]))
                {
                    this.mRegisteredIntepreters[(byte)e.Packet.ContentString[0]].Interprete(e.Packet);
                    if (ShowLog)
                    {
                        this.mLogForm.LogMessage(e.ReceivedTime, "Interpreter called.");
                    }
                }
                else {
                    if (ShowLog)
                    {
                        this.mLogForm.LogMessage(e.ReceivedTime, "no interpreter for that packet");
                    }
                }
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            mConnector.Start(ddlCOMPort.SelectedItem.ToString(), ckbAcceptMsg.Checked);
            (sender as Button).Enabled = false;
        }

        private void ckbShowLog_CheckedChanged(object sender, EventArgs e)
        {
            if ((sender as CheckBox).Checked)
            {
                mLogForm = new FrmLog();
                this.mLogForm.FormClosed += new FormClosedEventHandler(LogForm_FormClosed);
                this.mLogForm.Show(this);

            }
            else {
                if (this.mLogForm != null && !this.mLogForm.IsDisposed && this.mLogForm.Visible) {
                    this.mLogForm.Close();
                    this.mLogForm.Dispose();
                    this.mLogForm = null;
                }
            }
        }

        private void LogForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ckbShowLog.Checked = false;
        }

        private void trbContrast_Scroll(object sender, EventArgs e)
        {
            if (this.mConnector.SendSetContrast(trbContrast.Value))
            {
                lblContrastVal.Text = "(" + trbContrast.Value + ")";
            }

            //int vC = trbContrast.Value+ 128; //to avoid sending the FATAL 0 on the serial link)

            ////string vL = this.mConnector.DEBUG_SendPacketAndReturnLineContent("" + (char)vC, (byte)Constants.TYPE_OUT_SETCONTRAST, (byte)Constants.TYPE_OUT_SETCONTRAST);
            //string vL = this.mConnector.DEBUG_SendPacketAndReturnLineContent("" + (char)vC + vC.ToString() +"bonjour", (byte)Constants.TYPE_OUT_SETCONTRAST, (byte)Constants.TYPE_OUT_SETCONTRAST);
            //if (ShowLog)
            //{
            //    this.mLogForm.LogMessage(DateTime.Now, vL);
            //}
        }

        private void btnSendText_Click(object sender, EventArgs e)
        {
            this.mConnector.SendText(txbSendText.Text);
        }

        private void btnTestMonitorMail_Click(object sender, EventArgs e)
        {
            this.mConnector.SendMailMessage("zero mail", 0);
            Thread.Sleep(1500);
            this.mConnector.SendMailMessage("cent mails", 100);
            Thread.Sleep(1500);
            this.mConnector.SendMailMessage("deux cent cinquante six mails", 256);
            Thread.Sleep(1500);
            this.mConnector.SendMailMessage("beaucoup de mails", 1234);
            Thread.Sleep(1500);
        }

        private void timOutlook_Tick(object sender, EventArgs e)
        {

            try
            {
                int vMessCount = this.mOutlook.GetUnreadMessagesLateBound();
                if (vMessCount != this.mOutlook.mLastMessageCount)
                {
                    this.mOutlook.mLastMessageCount = vMessCount;
                    string vMessage = this.mOutlook.GetLastMessageTitleLateBound();
                    this.mConnector.SendMailMessage(vMessage.Substring(0, Math.Min(ARCPO.ARCPO_Packet.CONTENT_LENGTH - 2, vMessage.Length)), vMessCount);
                }
            }
            catch (Exception ex)
            {
                if (ShowLog)
                {
                    this.mLogForm.LogMessage(DateTime.Now, "ERROR CHECKING OUTLOOK: " + ex.Message);
                }
            }
        }

        private void ckbMailMonitor_CheckedChanged(object sender, EventArgs e)
        {
            this.timOutlook.Enabled = (sender as CheckBox).Checked;
        }
    }
}